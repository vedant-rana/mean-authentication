import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { CookieService } from 'ngx-cookie-service';

export const authGuard: CanActivateFn = (route, state) => {
  const router = inject(Router);
  const cookieService = inject(CookieService);

  const authCookie = cookieService.get('token');
  // console.log(authCookie);

  if (authCookie) {
    // console.log('Authentication successful');
    return true;
  } else {
    // console.log('No authentication token found, redirecting to register');
    router.navigate(['/register']);
    return false;
  }
};
