import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { loginUserType, regiterUserType } from '../types/userTypes';

@Injectable({
  providedIn: 'root',
})
export class UserService {
  constructor(private http: HttpClient, private router: Router) {}

  registerUser(userData: regiterUserType) {
    return this.http.post(
      'http://localhost:4000/api/v1/users/register',
      userData,
      {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
        }),
        observe: 'response',
        withCredentials: true,
      }
    );
  }

  loginUser(loginData: loginUserType) {
    return this.http.post(
      'http://localhost:4000/api/v1/users/login',
      loginData,
      {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
        }),
        observe: 'response',
        withCredentials: true,
      }
    );
  }

  getUserData() {
    return this.http.get('http://localhost:4000/api/v1/users', {
      withCredentials: true,
    });
  }

  logoutUser() {
    return this.http.get('http://localhost:4000/api/v1/users/logout', {
      withCredentials: true,
    });
  }
}
