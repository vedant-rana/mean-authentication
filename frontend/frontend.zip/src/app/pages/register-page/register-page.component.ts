import { Component, inject } from '@angular/core';
import {
  FormBuilder,
  Validators,
  ReactiveFormsModule,
  FormGroup,
} from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule, MatCardTitle } from '@angular/material/card';
import { MatSelectModule } from '@angular/material/select';
import { MatRadioModule } from '@angular/material/radio';
import { UserService } from '../../services/user.service';
import { regiterUserType } from '../../types/userTypes';
import { CommonService } from '../../services/common.service';
import { Router } from '@angular/router';
import { NgToastService } from 'ng-angular-popup';

@Component({
  selector: 'app-register-page',
  standalone: true,
  imports: [
    MatFormFieldModule,
    ReactiveFormsModule,
    MatInputModule,
    MatIconModule,
    MatButtonModule,
    MatCardModule,
    MatCardTitle,
    MatSelectModule,
    MatRadioModule,
  ],
  templateUrl: './register-page.component.html',
  styleUrl: './register-page.component.css',
})
export class RegisterPageComponent {
  constructor(
    private userService: UserService,
    private commonService: CommonService,
    private router: Router,
    private toaster: NgToastService
  ) {}
  formBuilder = inject(FormBuilder);
  passwordHide: boolean = true;
  confirmPasswordHide: boolean = true;

  userRegistration: FormGroup = this.formBuilder.group(
    {
      name: [
        '',
        [
          Validators.required,
          Validators.pattern(/^[a-zA-Z\s]+$/),
          Validators.minLength(2),
          Validators.maxLength(30),
        ],
      ],
      email: ['', [Validators.email, Validators.required]],
      mobile: ['', [Validators.required, Validators.pattern(/^\d{10}$/)]],
      gender: ['', Validators.required],
      city: ['', Validators.required],
      password: ['', [Validators.required, Validators.minLength(6)]],
      confirmPassword: ['', Validators.required],
    },
    { validators: this.passwordMatchValidator }
  );

  passwordMatchValidator(formGroup: FormGroup) {
    const password = formGroup.get('password')?.value;
    const confirmPassword = formGroup.get('confirmPassword')?.value;

    if (password !== confirmPassword) {
      formGroup.get('confirmPassword')?.setErrors({ passwordMismatch: true });
    } else {
      formGroup.get('confirmPassword')?.setErrors(null);
    }
  }

  changePasswordVisibility(event: MouseEvent) {
    this.passwordHide = !this.passwordHide;
    event.stopPropagation();
  }
  changeConfirmPasswordVisibility(event: MouseEvent) {
    this.confirmPasswordHide = !this.confirmPasswordHide;
    event.stopPropagation();
  }

  submitUserData() {
    if (this.userRegistration.valid) {
      const newUser: regiterUserType = {
        name: this.userRegistration.value.name!,
        email: this.userRegistration.value.email!,
        password: this.userRegistration.value.password!,
        mobile: Number(this.userRegistration.value.mobile!),
        gender: this.userRegistration.value.gender!,
        city: this.userRegistration.value.city!,
      };

      this.userService.registerUser(newUser).subscribe({
        next: (data) => {
          this.router.navigate(['/']);
          this.commonService.userLoggedIn.emit(true);
          this.toaster.success({
            detail: 'SUCCESS',
            summary: 'User Registered successfully',
            duration: 3000,
          });
        },
        error: (err) => {
          this.toaster.error({
            detail: 'ERROR',
            summary: err.error.message,
            duration: 3000,
          });
        },
      });
    } else {
      console.log('Form validation failed');
    }
  }
}
