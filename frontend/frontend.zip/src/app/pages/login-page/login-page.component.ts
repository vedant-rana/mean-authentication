import { Component } from '@angular/core';
import { FormBuilder, Validators, ReactiveFormsModule } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule, MatCardTitle } from '@angular/material/card';
import { UserService } from '../../services/user.service';
import { loginUserType } from '../../types/userTypes';
import { Router } from '@angular/router';
import { CommonService } from '../../services/common.service';
import { NgToastService } from 'ng-angular-popup';

@Component({
  selector: 'app-login-page',
  standalone: true,
  imports: [
    MatFormFieldModule,
    ReactiveFormsModule,
    MatInputModule,
    MatIconModule,
    MatButtonModule,
    MatCardModule,
    MatCardTitle,
  ],
  templateUrl: './login-page.component.html',
  styleUrl: './login-page.component.css',
})
export class LoginPageComponent {
  passwordHide: boolean = true;

  constructor(
    private fb: FormBuilder,
    private userService: UserService,
    private router: Router,
    private commonService: CommonService,
    private toaster: NgToastService
  ) {}

  userLogin = this.fb.group({
    email: ['temp1@gmail.com', [Validators.required, Validators.email]],
    password: ['123456', Validators.required],
  });

  changePasswordVisibility(event: MouseEvent) {
    this.passwordHide = !this.passwordHide;
    event.stopPropagation();
  }

  submitLoginData() {
    if (this.userLogin.valid) {
      const loginUserData: loginUserType = {
        email: this.userLogin.value.email!,
        password: this.userLogin.value.password!,
      };

      this.userService.loginUser(loginUserData).subscribe({
        next: (data) => {
          this.router.navigate(['/']);
          this.commonService.userLoggedIn.emit(true);
          this.toaster.success({
            detail: 'SUCCESS',
            summary: 'User logged in successfully',
            duration: 3000,
          });
        },
        error: (err) => {
          this.toaster.error({
            detail: 'ERROR',
            summary: err.error.message,
            duration: 3000,
          });
        },
      });
    } else {
      console.log('User Validation Failed');
    }
  }
}
