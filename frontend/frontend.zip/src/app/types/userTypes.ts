export type regiterUserType = {
  name: string;
  email: string;
  password: string;
  mobile: number;
  gender: string;
  city: string;
};

export type loginUserType = {
  email: string;
  password: string;
};
