import { inject } from '@angular/core';
import { CookieService } from 'ngx-cookie-service';

export const isThereCookie = () => {
  const cookieService = inject(CookieService);
  if (cookieService.get('token')) {
    return true;
  }
  return false;
};
